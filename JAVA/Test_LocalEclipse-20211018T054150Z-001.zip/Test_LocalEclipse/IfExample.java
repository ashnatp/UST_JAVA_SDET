package com.ust.test;

public class IfExample {

	public static void main(String[] args) {
		int age=25;
		if(age>18) {
			System.out.println("You are a major");
			
		}
		else {
			System.out.println("You are a minor");
		}
		// TODO Auto-generated method stub

	}

}
