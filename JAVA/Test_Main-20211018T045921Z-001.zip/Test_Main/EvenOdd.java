package com.ust.test;

public class EvenOdd {

	public static void main(String[] args) {
		int n=13;
		if(n%2==0) {
			System.out.println("It is even number");
		}
		else {
			System.out.println("Is is odd number");
		}
		// TODO Auto-generated method stub

	}

}

