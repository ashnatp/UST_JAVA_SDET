package com.ust.test;

public class This_Teat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
