package com.ust.test;

public class ArrayExample {

	public static void main(String[] args) {
		int[] numbers= {1,2,-1,-2};
		for(int number: numbers) {
			System.out.println(number);;
		}

}
}
