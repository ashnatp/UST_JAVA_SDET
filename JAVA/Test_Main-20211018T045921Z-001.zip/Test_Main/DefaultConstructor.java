package com.ust.test;

public class DefaultConstructor {
	int a;
	boolean b;

	public static void main(String[] args) {
		DefaultConstructor ob=new DefaultConstructor();
		
		System.out.println("Deafault value:");
		System.out.println("a="+ob.a);
		System.out.println("b="+ob.b);
		
		

	}

}
