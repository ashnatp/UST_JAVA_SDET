/*package com.ust.test;

class PublicConstructor {
	String name;
	
	public PublicConstructor(){
		name="ABC";
	}
	

public static void main(String[] args) {
			PublicConstructor ob=new PublicConstructor();
			
			
			
		}
		

	}*/



	
	