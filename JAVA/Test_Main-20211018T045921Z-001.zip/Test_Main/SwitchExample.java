package com.ust.test;

public class SwitchExample {

	public static void main(String[] args) {
		String s = "rany";
		switch(s) {
		case "rani":
			System.out.println("you displayed rani");
			break;
		default:
			System.out.println("He is king");
			break;
		case "raju":
			System.out.println("you displayed raju");
			break;
		
		}
		
	}

}
