package com.ust.test;

public class ArrayForExample {

	public static void main(String[] args) {
		int[] age= {1,15,16};
		System.out.println("Usage of for loop");
		for(int i=0;i<age.length;i++) {
			System.out.println(age[i]);
		}

	}

}
