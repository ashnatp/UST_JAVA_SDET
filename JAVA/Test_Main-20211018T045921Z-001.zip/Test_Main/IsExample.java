package com.ust.test;

public class IsExample {

	public static void main(String[] args) {
		int age=17;
		if(age>18) {
			System.out.println("Your age is greater than 18 years");
		}
		else {
			System.out.println("Your age is less than 18 years");
		}
		// TODO Auto-generated method stub

	}

}
